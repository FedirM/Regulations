---
title: Border inner
categories:
  - UI and keyboard
tags:
  - borders
---
